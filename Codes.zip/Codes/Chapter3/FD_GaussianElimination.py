# -*- coding: utf-8 -*-
"""
Created on Sun Feb  9 09:48:35 2020

@author: Dr. Srinath Madasu
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Oct 30 14:10:35 2019

@author: Dr. Srinath Madasu
"""
import numpy as np
def gauss(A):
    n = len(A)

    for i in range(0, n):
        # Search for maximum in this column
        maxEl = abs(A[i][i])
        maxRow = i
        for k in range(i+1, n):
            if abs(A[k][i]) > maxEl:
                maxEl = abs(A[k][i])
                maxRow = k

        # Swap maximum row with current row (column by column)
        for k in range(i, n+1):
            tmp = A[maxRow][k]
            A[maxRow][k] = A[i][k]
            A[i][k] = tmp

        # Make all rows below this one 0 in current column
        for k in range(i+1, n):
            c = -A[k][i]/A[i][i]
            for j in range(i, n+1):
                if i == j:
                    A[k][j] = 0
                else:
                    A[k][j] += c * A[i][j]

    # Solve equation Ax=b for an upper triangular matrix A
    x = [0 for i in range(n)]
    for i in range(n-1, -1, -1):
        x[i] = A[i][n]/A[i][i]
        for k in range(i-1, -1, -1):
            A[k][n] -= A[k][i] * x[i]
    return x

if __name__ == "__main__":
    L = 1
    T = 1
    dx = 0.02
    a = 1
    F = 0.5
    dt = F/a*dx**2
    def I(x):
            """Plug profile as initial condition."""
            if abs(x-L/2.0) > 0.1:
                return 0
            else:
                return 1
    def f(x, t):
            return 5*x*(L-x) + 10*a*t
        
    Nt = int(round(T/float(dt)))
    Nx = int(round(L/dx))
    x = np.linspace(0, L, Nx+1)    # mesh points in space
    dx = x[1] - x[0]
    t = np.linspace(0, T, Nt+1)    # mesh points in time
    dt = t[1] - t[0]
    F = a*dt/dx**2
    n = Nx+1  

    
    u_n = np.zeros(Nx+1)  
    u   = np.zeros(Nx+1)
    b = np.zeros(Nx+1)
     # Set initial condition u(x,0) = I(x)
    for i in range(0, Nx+1):
            u_n[i] = I(x[i])
    for nt in range(0, Nt):
        A = [[0 for j in range(n+1)] for i in range(n)]
   
        for i in range(0, n):
            for j in range(0,n):
                if i==0 and j==0:
                    A[i][j] = 1.
                elif i==0 and j==1:
                    A[i][j] = 0.
                elif i==n-1 and j==n-1:
                    A[i][j] = 1.
                elif i==n-1 and j==n-2:
                    A[i][j] = 0.
                elif i==j+1:
                    A[i][j] = -F
                elif i==j:
                    A[i][j] = 1+2*F
                elif i==j-1:
                    A[i][j] = -F
       
    
    
    
        # Compute b and solve linear system
        for i in range(1, Nx):
            b[i] = u_n[i]+ dt*f(x[i], t[nt])
        b[0] = b[Nx] = 0
        for i in range(0, Nx+1):
            A[i][n]=b[i]
                  
        # Calculate solution
        u[:] = gauss(A)
        # Update u_n before next step
        u_n[:] = u 
        