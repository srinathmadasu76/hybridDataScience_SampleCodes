# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 08:48:01 2020

@author: HB65402
"""
import numpy
from keras.models import Sequential
from keras.layers import Dense
import matplotlib.pyplot as plt
import pandas as pd
# load the dataset
df = pd.read_csv('FieldPlanData.csv',header=0)
df = df[['Fractures','Length','Production']]
dataset = df.values
# split into input (X) and output (y) variables
X = dataset[:,0:2]
y = dataset[:,2]
def getRangeNorm(v):
    vMax = numpy.max(v)
    vMin = numpy.min(v)
    vRange = vMax - vMin
    vNorm = (v - vMin) / vRange
    return vMax, vMin, vRange, vNorm  

def getNormToOriginal(vNorm, vMin, vRange):
    return (vNorm * vRange + vMin)
    
def split_data(data, test_size=0.2):
    """
    splits data to training, validation and testing parts
    """
    ntest = int(round(len(data) * (1 - test_size)))
    

    df_train, df_test = data.iloc[:ntest],  data.iloc[ntest:]

    return df_train, df_test

x1Max, x1Min, x1Range, x1Norm = getRangeNorm(X[:,0])
x2Max, x2Min, x2Range, x2Norm = getRangeNorm(X[:,1])
y1Max, y1Min, y1Range, y1Norm = getRangeNorm(y)
train_X = (numpy.c_[x1Norm,x2Norm])  
  
train_Y = numpy.c_[y1Norm]
 
# define the keras model
model = Sequential()
model.add(Dense(10, input_dim=2, activation='relu'))
model.add(Dense(1, activation='linear'))
# compile the keras model
model.compile(loss='mse', optimizer='adam', metrics=['accuracy'])
# fit the keras model on the dataset
history = model.fit(train_X, train_Y, epochs=500, batch_size=15, verbose=0)
# plot history
fig = plt.figure(1)
ax = fig.add_subplot(1,1,1)
ax.set_xticks(numpy.arange(1,501,1))
x=numpy.arange(1,501,1)
plt.plot(x,history.history['loss'], label='train')
plt.xlabel('Iterations',fontsize=12)
plt.ylabel('Loss',fontsize=12)
plt.xticks(fontsize=12)
plt.yticks(fontsize=12)
plt.legend(prop={'size':10})
# make predictions
trainPredict = model.predict(train_X)
resultn = getNormToOriginal(numpy.array(trainPredict), y1Min, y1Range)
numpy.savetxt('prodkeras.csv',numpy.c_[resultn,y],fmt=['%0.5f','%0.5f'],delimiter=',',header="Predicted,Actual",comments='')